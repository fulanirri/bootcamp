package AudioPlayer;


public interface AudioFile {
    
    public String play();
    public String stop();
    public String pause();
    
    

}
